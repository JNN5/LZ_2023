"""
Types used in pynamodb
"""

STRING = 'S'
NUMBER = 'N'
BINARY = 'B'
HASH = 'HASH'
RANGE = 'RANGE'
